function showLoginForm()
{
	document.getElementById("login-form").style.display="inline-block";
	document.getElementById("signup-form").style.display="none";
}
function showSignupForm()
{
	document.getElementById("signup-form").style.display="inline-block";
	document.getElementById("login-form").style.display="none";
}
<html>
  <head>
  <title>SUCCESSFULLY SIGNED UP</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>
 
    
    <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
          
        <br><br>
    
  <body>

	<?php 

	     $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="project";;
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
	       }else
	       die("Could not connect to database: ");


		 $first= $_POST['fname'];
		 $last= $_POST['lname'];
		 $user= $_POST['username'];
		 $mail= $_POST['email'];
		 $pass= $_POST['password']; 
		 $a= $_POST['age'];
		 $loc=$_POST['location'];
		 $exp= $_POST['experience'];
		 $qua= $_POST['qualification'];
		 $no= $_POST['mobileno'];
		 
	        
            if (!filter_var($mail, FILTER_VALIDATE_EMAIL)){
              echo "Invalid Email.......";
            }else{
             $result = mysql_query("SELECT * FROM job_seeker WHERE email='$mail'");
             $data = mysql_num_rows($result);
             if(($data)==0){ 
             $query = mysql_query("INSERT INTO `job_seeker`(f_name, l_name, username) VALUES ('aaa', 'bbb', 'ababab')"); // Insert query
if($query){
echo "              You have Successfully Registered.....";
}else
{
echo "Error....!!";
}
}else{
echo "This email is already registered, Please try another email...";
}
}
mysql_close ($connection);
?>
	       
	         
  </body>
</html>
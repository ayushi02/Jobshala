<html>
  <head>
  <title>SUCCESSFULLY  LOGGED IN</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
        <style>
div.img {
    margin: 10px;
    
    float: right;
    width: 50px;
}

div.img:hover {
    border: 4px solid #777;
}

div.img img {
    width: 100%;
    height: auto;
}
div.desc {
    padding: 3px;
    text-align: center;
}
div.box {
    background-color:rgb(255,125,190);
    width: 300px;
    border: 5px solid rgb(11,27,136); ;
    padding: 25px;
    margin: 25px;
}
</style>
    </head>
 
    
    <body >
     <form method="post" action=edit1.php >   
        <link rel="stylesheet" type="text/css" href="edit1.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
     <nav>
         <ul>
          <li>
            <a href="edit1.php">Edit</a>
          </li>
          <li>
            <a href="#">Recommendation</a>
          </li>
          <li>
            <a href="helpp.html">Help</a>
          </li>
          <li>
            <a href="logout.html">Sign out</a>
          </li>
        </ul>
       </nav>
        <br><br>
    
  <body>
  <script type="text/javascript">
       tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
       tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

      function GetClock(){
var d=new Date();
var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear();
if(nyear<1000) nyear+=1900;
var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

if(nhour==0){ap=" AM";nhour=12;}
else if(nhour<12){ap=" AM";}
else if(nhour==12){ap=" PM";}
else if(nhour>12){ap=" PM";nhour-=12;}

if(nmin<=9) nmin="0"+nmin;
if(nsec<=9) nsec="0"+nsec;

document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+ap+"";
}

window.onload=function(){
GetClock();
setInterval(GetClock,1000);
}
</script>

<div id="clockbox" align="right"></div>
         
  <?php 

       $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="project";
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
         }else
         die("Could not connect to database: ");


     
     $user= $_POST['username'];
     $pass= $_POST['password']; 
    
     
                                $result = mysql_query("SELECT * from `job_seeker` where username='$user' && password='$pass'");
                                $row = mysql_fetch_object($result);
                               if ($row->id>=0) {
                                  echo "<font size=6 face='Arial'>";
                                  echo " HEY  ";
                                  echo "<font size=5 face='Arial'>";
                                  echo $row->f_name;
                                  echo "  ";
                                  echo $row->l_name;
                                  echo " ,\n";
                                  
                                    }

                                 else {
                                  echo "                  INVALID USERNAME OR PASSWORD...\n                 PLEASE LOGIN AGAIN";
                                  }
mysql_free_result($result);
?>
<div class="img">
    <img src="face3.jpg" alt="user" width="200" height="200">
  
  <div class="desc"> 
   <?php
   echo "<font size=2 face='Arial'>";
   echo $row->username;
   ?>
 </div>
</div>
<div> 
<h2><center>VIEW YOUR PROFILE</h2></center>
<br><br><br>
</div>
<center>
<div class="box">
                           <?php 
                                  echo "<font size=4 face='Arial'>";
                                  echo " FULL NAME :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->f_name;
                                  echo "  ";
                                  echo $row->l_name;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo " DATE OF BIRTH :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->DOB;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo " EMAIL :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->email;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo " EXPERIENCE :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->experience;
                                  echo " years.";
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo " MOBILE NO :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->mobile_no;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo " GENDER :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->gender;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo " LOCATION :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->location;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo " QUALIFICATON:";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->qualification;
                            ?>
</div>

                             <br>
                            
</center>
</body>
</html>
<html>
    <head>
     <head>
     <style>
      .error {color: #FF0000;}
     </style>
        <title>company</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>   
       <body bgcolor="#E6E6FA">
        <link rel="stylesheet" type="text/css" href="edit1.css">
         <img src="banner.png" id="banner">
          <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
          </div>
        <nav>
         <ul>
          <li>
            <a href="#">Home</a>
          </li>
          <li>
            <a href="#">Blog</a>
          </li>
          <li>
            <a href="#">About</a>
          </li>
          <li>
            <a href="#">Contact</a>
          </li>
        </ul>
       </nav>
          
       
 <form method="post" action=hcl.php>       
<div id="last" >
   <div class="form">
    
    <div id="pic1"><right><img src="o.png" width="100%" height="100px" ><input type="submit" name="company" value="hcl"></img></right></div>
    <div id="pic7"><center><img src="oracle.png" width="100%" height="100px"><center><input type="submit" name="company" value="oracle"></center></img></center></div>
    <div id="pic"><left><img src="cc.png" width="100%" height="100px"><center><input type="submit" name="company" value="reliance"></center></img></left></div>

    <div id="pic4"><right><img src="wipro.jpg" width="100%" height="100px" ><center><input type="submit" name="company" value="wipro"></center></img></right></div>
    <div id="pic5"><center><img src="download.png" width="100%" height="100px"><center><input type="submit" name="company" value="amazon"></center></img></center></div>
    <div id="pic6"><left><img src="ff.png" width="100%" height="100px"><center><input type="submit" name="company" value="cognizant"></center></img></left></div>
    <div id="pic4"><right><img src="paytm.png" width="100%" height="100px" ><center><input type="submit" name="company" value="paytm"></center></img></right></div>
    <div id="pic5"><center><img src="flipkart.jpg" width="100%" height="100px"><center><input type="submit" name="company" value="flipkart"></center></img></center></div>
    <div id="pic6"><left><img src="aa.png" width="100%" height="100px"><center><input type="submit" name="company" value="google"></center></img></left></div>
    <div id="pic4"><right><img src="de.png" width="100%" height="100px" ><center><input type="submit" name="company" value="deloitte"></center></img></right></div>
    <div id="pic5"><center><img src="doc.png" width="100%" height="100px"><center><input type="submit" name="company" value="docomo"></center></img></center></div>
    
    <div id="pic4"><right><img src="no.png" width="100%" height="100px" ><center><input type="submit" name="company" value="novaritis"></center></img></right></div>



   </div>
</div>
</form> 
</body>
</html>
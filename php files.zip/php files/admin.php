<html>
    <head>
     <head>
     <style>
      .error {color: #FF0000;}
     </style>
        <title>ADMIN'S PAGE</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>   
       <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
     <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
        
        <br><br>  
          
          <center>  <h2><u>DATABASE:</u></h2></center><br>
        
        
<div id="last" class="form">
<form method="post" action=dd2.php method=post>
<?php
$hostname = "localhost";
$username = "root";
$password = "";
$mydb="project";


if(mysql_connect($hostname, $username, $password) && mysql_select_db($mydb)){
  
}else
  die("Could not connect to database: "); 
                                echo '<center> EMPLOYEE DATABASE:</CENTER><br><br>';
                                echo '<center><table cellspacing="6" cellpadding="5" border="1">';
                                echo '<tr><th>full_name</th><th>location</th><th>DOB</th><th>email</th><th>username</th><th>status</th>';
                                $query = mysql_query("SELECT full_name ,location,DOB,email,username,state from `job_seeker`");
                                 for($count=0;$row=mysql_fetch_row($query);$count++)
                                 {  echo '<tr>';
                                     foreach( $row as $key => $value)
                                      echo '<td>'.$value.'</td>';
                                     echo'</tr>';
                                 
                                }
                                   echo '</table></center>'; 
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                echo '<center> STUDENT DATABASE:</CENTER><br><br>';
                                echo '<center><table cellspacing="6" cellpadding="5" border="1">';
                                echo '<tr><th>f_name</th><th>location</th><th>DOB</th><th>email</th><th>username</th><th>status</th>';
                                $queryy = mysql_query("SELECT f_name ,location,DOB,email,username,state from `student`");
                                 for($counted=0;$row=mysql_fetch_row($queryy);$counted++)
                                 {  echo '<tr>';
                                     foreach( $row as $key => $value)
                                      echo '<td>'.$value.'</td>';
                                     echo'</tr>';
                                 
                                }
                                echo '</table></center>';  
?>

   
</form>
 
</div>
</body>
</html>
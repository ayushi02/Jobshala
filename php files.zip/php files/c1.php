<html>
  <head>
  <title>company's info</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
  
    </head>
 
    
    <body bgcolor="#E6E6FA">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
     
        <br><br>
    
  <body>
  
	<?php 

	     $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="project";
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
	       }else
	       die("Could not connect to database: ");


		 
		 $cname= $_POST['company'];
		 
		
		 
                                $result = mysql_query("SELECT * from `company` where name='$cname'");
                                $row = mysql_fetch_object($result);
                               if ($row->c_id>=0) {
                                  echo "<font size=6 face='Arial'>";
                                  echo " NAME : ";
                                  echo "<font size=5 face='Arial'>";
                                  echo $row->name;
                                   echo  nl2br ("\n");
                                  
                                    }

                                 else {
                                  echo "  no company is found with this name";
                                  }
mysql_free_result($result);
?>


</body>
</html>
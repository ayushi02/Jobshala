<html>
  <head>
	<title>Password test</title>
  <head>

  <body>
	<FORM ACTION=demo2.php METHOD=POST>
	   name: <INPUT TYPE=TEXT NAME="realname"><BR>
	   password: <INPUT TYPE=PASSWORD NAME="mypassword">
	  <P><INPUT TYPE=SUBMIT VALUE="submit">
	</FORM>
  </body>
</html>
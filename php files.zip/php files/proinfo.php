<html>
  <head>
  <title>products decription</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
  
    </head>
 
    
    <body bgcolor="#E6E6FA">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">RURAL DEVELOPMENT</h1></a>
            <h4 id="subjob">We Make It Better</h4>
        </div>
     
        <br><br>
    
  <body>
  <div class="form">
	<?php 

	     $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="rural";
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
	       }else
	       die("Could not connect to database: ");


		 
		
		 
                              for ($x = 1; $x <= 4; $x++) 
                              {
     
                                $result = mysql_query("SELECT * from `pro_info` where c_id=$x");
                                $row = mysql_fetch_object($result);
                               
                                  echo "<font size=4 face='Arial'>";
                                  echo "<center><u>PRODUCT </u>: ";
                                  echo "<font size=4 face='Arial'>";
                                  echo $row->pname;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo "<center>PRICES";
                                  echo "<font size=3 face='Arial'>";
                                 
                                  echo $row->price;
                                  echo "RS.";
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                    
                                
                                 }
mysql_free_result($result);
?>

</form>
</body>
</html>
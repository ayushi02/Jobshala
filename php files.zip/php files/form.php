<html>
    <head>
    <style>
.error {color: #FF0000;}

    </style>
        <title>JOBSHALA SIGN UP</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs">
        
    </head>
 
    
    <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
        
        
        
        <br><br>
    <center>  <h2>SIGN UP here</h2></center>
      <form method="post" action=dd.php enctype="multipart/form-data""> 
      <!-- ADD LINK HERE IN HREF SEEEEEEEEEEEEEEEEEEE ABOVE -->
        
        
        <div id="last" class="form">
 <?php  
    session_start();
    $_SESSION['table'] = $_POST['category'];    
echo '<center><p><span class="error">* required field.</span></p>';

echo '<table>
<tr><td><b>First Name:</td><td> <input type="text" name="fname">
  <span class="error">* </span></td></tr>
  
  <tr><td>Last Name: </td><td><input type="text" name="lname">
  <span class="error">* </span></td></tr>
  
  <tr><td>User Name:</td><td> <input type="text" name="username">
  <span class="error">* </span></td></tr>
  
  <tr><td><b>E-mail:</td><td> <input type="text" name="email">
  <span class="error">*</span></td></tr>
  
  <tr><td>Password :</td><td> <input type="text" name="password">
  <span class="error">* </span></td></tr>
  
  <tr><td>dob(yyyy-mm-dd):</td><td><input type="text" name="dob">
  <span class="error">* </span></td></tr>
  
  <tr><td>Location:</td><td> <input type="text" name="location"></td></tr>';
  if($_POST['category']=='Employee'||$_POST['category']=='Admin')
  {echo '<tr><td>Experience:</td><td> <input type="text" name="experience"> years</td></tr>';}
   if($_POST['category']=='Employee'||$_POST['category']=='Admin')
  {echo '<tr><td>Qualification: </td><td><input type="text" name="qualification"></td></tr>';}
  
  echo '<tr><td>Mobile No.: </td><td><input type="text" name="mobileno"></td></tr>
  
  </table>
  Feedback:
  <br> <textarea name="feedback" rows="5" cols="40"></textarea>
  <br><br>
  Gender &emsp; :
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <span class="error">* </span>
  <br><br>
  Select Image:
    <input type="file" name="image" >
    
    <br><br>';
    if($_POST['category']=='Employee')
    {echo 'Upload Resume:
    <input type="file" name="resume" >
    </b>
    <br><br>';}
    ?>
  <input type="submit" name="submit" value="Sign up"> </p> 
</form>

 </center>
</div>

</body>
</html>
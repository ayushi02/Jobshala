<html>
  <head>
  <title>company's info</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
  
    </head>
 
    
    <body bgcolor="#E6E6FA">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
     
        <br><br>
    
  <body background="b8.jpg">
  <div class="form">
	<?php 

	     $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="project";
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
	       }else
	       die("Could not connect to database: ");


		 
		      $cname= $_POST['location'];
		                           echo "<font size=4 face='Arial'>";
                                 echo "<center><u><b>DETAILS</b></u><br><br><br></center>";
                                 echo"<table>";
		                          for ($x = 1; $x <= 13; $x++) 
                              {
		 
                                $result = mysql_query("SELECT * from `company` where c_id=$x");
                                $row = mysql_fetch_object($result);
                               if ($row->location==$cname) {
                                  echo "<tr><font size=3 face='Arial'>";
                                  echo " <span style='color:red'><center><u>COMPANY NAME </u></span>: ";
                                  echo "<font size=2 face='Arial'>";
                                  echo "<span style='color:black'>".$row->name."</tr>";
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<tr><font size=3 face='Arial'>";
                                  echo "<span style='color:red'><center><u>LOCATION </u>:</span> ";
                                  echo "<font size=2 face='Arial'>";
                                  echo "<span style='color:black'>".$row->location."</tr>";
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<tr><font size=3 face='Arial'>";
                                  echo "<span style='color:red'><center><u>STATUS OF FORM </u>:</span> ";
                                  echo "<font size=2 face='Arial'>";
                                  echo "<span style='color:black'>".$row->status."</tr></span>";
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<tr><font size=3 face='Arial'>";
                                  echo "<span style='color:red'><center><u>USER RATING </u>: </span>";
                                  echo "<font size=2 face='Arial'>";
                                  echo "<span style='color:black'>".$row->priority."</tr></span>";
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<tr><font size=3 face='Arial'>";
                                  echo "<span style='color:red'><center>For Further Info click here:</span> ";
                                  echo "<font size=2 face='Arial'>";
                                  echo "<a href=$row->href>";
                                  echo "<span style='color:black'>".$row->href."</tr>";
                                  echo "</a>";
                                  echo  nl2br ("\n");
                                  echo '<center>*******************************************************************</center>';
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                    }
                                
                                 }
mysql_free_result($result);
?>

</form>
</body>
</html>
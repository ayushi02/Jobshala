<html>
    <head>
     <head>
     <style>
      .error {color: #FF0000;}
     </style>
        <title>JOBSHALA LOGIN IN</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>   
       <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
     <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
        
        <br><br>  
          
          <center>  <h2>LOGIN IN here</h2></center><br>
        
        
<div id="last" class="form">
<form method="post" action="dd2.php" id="myform">
<?php
$hostname = "localhost";
$username = "root";
$password = "";
$mydb="project";


if(mysql_connect($hostname, $username, $password) && mysql_select_db($mydb)){
  
}else
  die("Could not connect to database: "); 


?>
<center><B>SELECT YOUR CATEGORY :<B>
<select name="category">
  <option value="null">--Choose an option--</option>
  <option value="Student">Student</option>
  <option value="Employee">Employee</option>
  <option value="Admin">Admin</option>
</select>
</center>
<br><br><br>
<center>
<p><span class="error">* required field.</span></p>
<form method="post" action="<?php echo $data ?>">

 <b> User Name:</b> <input type="text" name="username">
  <span class="error">* </span>
  <br><br>
  
  <b>Password:</b> <input type="text" name="password">
  <span class="error">* </span>
  <br><br>
  <b>Today's Date:</b> <input type="date" name="tdate">
  <br><br>
  <?php
  $query="SELECT id FROM `user` where username=name && password=pass";
  $query_run=mysql_query($query);
  ?>
  <input type="submit" name="submit" value="Submit"> 
  <input type="button" onclick="myfunction()" value="Reset ">
</form>
 <script>
 function myfunction()
 {
  document.getElementById("myform").reset();
 }
 </script>
</div>
</body>
</html>
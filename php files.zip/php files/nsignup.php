<!DOCTYPE HTML>  
<html>
<head>
<title>JOBSHALA SIGN UP</title>
<meta http-equiv="author">
<meta description="description" content="Jobshala aspiring Jobs"> 
<style>
.error {color: #FF0000;}
</style>
</head>
<body bgcolor="#E6E6FA">  
<link rel="stylesheet" type="text/css" href="css.css">
        <img src="banner.png" id="banner">
        
        
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA.com</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>

<?php
// define variables and set to empty values
$fnameErr=$lnameErr=$usernameErr = $emailErr = $genderErr = $passwordErr = "";
$fname =$lname =$email=$username = $gender = $feedback = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }

  if (empty($_POST["username"])) {
    $usernameErr = "User Name is required";
  } else {
    $username = test_input($_POST["username"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  if (empty($_POST["password"])) {
    $passwordErr = "password id required";
  } else {
    $password = test_input($_POST["password"]);
  }

  if (empty($_POST["feedback"])) {
    $feedback = "";
  } else {
    $feedback = test_input($_POST["feedback"]);
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>

<h2><center>SIGN UP PAGE</h2>
<p><span class="error">* required field.</span></p>
<form method="post" action="<?php echo $data ?>">
First Name:  <input type="text" name="fname">
  <span class="error">* <?php echo $fnameErr;?></span>
  <br><br>
  Last Name: <input type="text" name="lname">
  <span class="error">* <?php echo $lnameErr;?></span>
  <br><br>
  User Name: <input type="text" name="username">
  <span class="error">* <?php echo $usernameErr;?></span>
  <br><br>
  E-mail: <input type="text" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  Password: <input type="text" name="password">
  <span class="error">* <?php echo $passwordErr;?></span>
  <br><br>
  Feedback:
  <br> <textarea name="feedback" rows="5" cols="40"></textarea>
  <br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form>

</body>
</html>
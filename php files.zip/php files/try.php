<!DOCTYPE html>
<html>
<head>
<title>
uploading images
</title>
</head>
<body>

<form action="try.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="image" >
    <input type="submit" name="upload" value="Upload Image">
</form>

<?php
   if(isset($_POST['upload']))
   {
   	 $image_name=$_FILES['image']['name'];
   	 $image_type=$_FILES['image']['type'];
   	 $image_size=$_FILES['image']['size'];
   	 $image_tmp_name=$_FILES['image']['tmp_name'];

     if($image_name=='')
     {
     	echo "<script>alert('Please Select an Image')</script>";
   	    exit();
     }
      else {
       	 	move_uploaded_file($image_tmp_name,"photos/$image_name");
       	 	echo "Image Uploaded Successfully";
       	 } 	 
   }

 ?>

</body>
</html>
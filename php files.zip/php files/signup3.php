<html>
    <head>
    <style>
.error {color: #FF0000;}

    </style>
        <title>JOBSHALA SIGN UP</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>
 
    
    <body bgcolor="#E6E6FA">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
        
        
        
      <!-- ADD LINK HERE IN HREF SEEEEEEEEEEEEEEEEEEE BELOW -->  
        
    <center>  <h3>SIGN UP here</h3></center>
       
      <!-- ADD LINK HERE IN HREF SEEEEEEEEEEEEEEEEEEE ABOVE -->
        
        
        
<div id="last" >
               <?php
// define variables and set to empty values
$fnameErr=$lnameErr=$usernameErr = $emailErr = $genderErr = $passwordErr=$ageErr = "";
$fname =$lname =$email=$username = $gender = $feedback = $password = $location=$qualification="";
$experience=$mobileno=$age=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["fname"])) {
    $fnameErr = "Name is required";
  } else {
    $fname = test_input($_POST["fname"]);
  }
 if (empty($_POST["lname"])) {
    $lnameErr = "Name is required";
  } else {
    $lname = test_input($_POST["lname"]);
  }
  if (empty($_POST["username"])) {
    $usernameErr = "User Name is required";
  } else {
    $username = test_input($_POST["username"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  if (empty($_POST["password"])) {
    $passwordErr = "password id required";
  } else {
    $password = test_input($_POST["password"]);
  }

  if (empty($_POST["feedback"])) {
    $feedback = "";
  } else {
    $feedback = test_input($_POST["feedback"]);
  }
 if (empty($_POST["location"])) {
    $location = "";
  } else {
    $location = test_input($_POST["location"]);
  }
  if (empty($_POST["experience"])) {
    $experience =0;
  } else {
    $exeriencep = test_input($_POST["experience"]);
  }
  if (empty($_POST["age"])) {
    $ageErr =" Age is required";
  } else {
    $age= test_input($_POST["age"]);
  }
  if (empty($_POST["mobileno"])) {
    $mobileno =0;
  } else {
    $mobileno= test_input($_POST["mobileno"]);
  }
  if (empty($_POST["qualification"])) {
    $qualification = "";
  } else {
    $qualification = test_input($_POST["qualification"]);
  }
  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>

<center>
<p><span class="error">* required field.</span></p>
<form method="post" action="<?php echo $data ?>">
First Name:  <input type="text" name="fname">
  <span class="error">* <?php echo $fnameErr;?></span>
  <br><br>
  Last Name: <input type="text" name="lname">
  <span class="error">* <?php echo $lnameErr;?></span>
  <br><br>
  User Name: <input type="text" name="username">
  <span class="error">* <?php echo $usernameErr;?></span>
  <br><br>
  E-mail: <input type="text" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  Password: <input type="text" name="password">
  <span class="error">* <?php echo $passwordErr;?></span>
  <br><br>
  Age: <input type="text" name="age">
  <span class="error">* <?php echo $ageErr;?></span>
  <br><br>
  Location: <input type="text" name="locaiton">
  <br><br>
  Experience: <input type="text" name="experience">
  <br><br>
  Qualification: <input type="text" name="qualification">
  <br><br>
  Mobile No.: <input type="text" name="mobileno">
  <br><br>
  Feedback:
  <br> <textarea name="feedback" rows="5" cols="40"></textarea>
  <br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form>
 
</div>
</body>
</html>
<html>
    <head>
     <head>
     <style>
      .error {color: #FF0000;}
     </style>
        <title>JOBSHALA LOGIN IN</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>   
       <body bgcolor="#E6E6FA">
     <link rel="stylesheet" type="text/css" href="edit1.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
        <nav>
         <ul>
          <li>
            <a href="#">Home</a>
          </li>
          <li>
            <a href="#">Blog</a>
          </li>
          <li>
            <a href="#">About</a>
          </li>
          <li>
            <a href="#">Contact</a>
          </li>
        </ul>
       </nav>
          
        
        
<div id="last" >
<div class="form">
<div id="pic1">
<right><img src="o.png" width="100%" height="100px" /></right>

<center><a href="hcl.php"><input type="submit" name="company" value="hcl"></a></center>
</div>

 </div>
</div>
</body>
</html>
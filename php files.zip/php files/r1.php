<html>
  <head>
  <title>RATED SUCCESSFULLY</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
        <style>
        .button{
         background-color:#aa4caf; /* purple */
         border: none;
         color: white;
         padding: 15px 40px;
         text-align: center;
         text-decoration: none;
         display: inline-block;
         font-size: 16px;
         margin: 4px 2px;
         border-color: white;
         border-radius: 8px;
         cursor: pointer;
}
        </style>
    </head>
 
    
    <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
          
        <br><br>
    
  <body>

	<?php 

	     $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="project";
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
	       }else
	       die("Could not connect to database: ");


		 $rate= $_POST['rating'];
		 
	       
             $query = mysql_query("INSERT INTO `rate_site`(rating) VALUES ($rate)");
if($query){
 echo "<font size=4 face='Arial'>";
 echo "'<CENTER>THANKX FOR RATING OUR SITE ";
 
 echo  nl2br ("\n");
 echo "<font size=3 face='Arial'>";
 echo "'<CENTER>WE ASSURE YOU FOR OUR BEST SERVICE. ";
 
 echo  nl2br ("\n");
 echo  nl2br ("\n"); 

 }        

mysql_close($connection);
?>
<center><button class="button"><b><a href="http://localhost/proj/index%20(1).html">Back to Main Page</a></center></b></button>
</body>
</html>
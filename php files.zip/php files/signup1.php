<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="formoid_files/formoid1/style.css" type="text/css" />
<script type="text/javascript" src="formoid_files/formoid1/jquery.uniform.min.js"></script>
</head>
<body>
<!-- Start Formoid form-->
<form action="" name="contactUser" class="myForm1" title="Contact Registered Users">
    <label class="title">User ID </label>
    <input type="text" name="userID" size="12">
    <br>
    <br>
    <label class ="title">FIRST NAME</label>
    <input type="text" name="f_name" size="12">
    <br>
    <br>
    <label class ="title">LAST NAME</label>
    <input type="text" name="l_name" size="12">
    <br>
    <br>
    <label class ="title">EMAIL</label>
    <input type="text" name="email" size="50">
    <br>
    <br>
    <label class ="title">EXPERIENCE</label>
    <input type="text" name="experience" size="12">
    <br>
    <br>
    <label class ="title">LOCATION</label>
    <input type="text" name="location" size="12">
    <br>
    <br>
    <label class ="title">SKILLS</label>
    <input type="text" name="skills" size="12">
    <br>
    <br>
    <label class="title">GENDER</label><br>
    <input type="checkbox" name="GENDER" value="MALE">MALE<br>
    <input type="checkbox" name="GENDER" value="FEMALE">FEMALE  <br>
    <label class="title">Message</label>
    <br />
    <textarea name="message" cols="20" rows="5"></textarea>
    <br />
    <input type="button" name="reset" value="Reset Form">  <input type="submit" name="submit" value="Submit">                                                                                                                                                                                                                                         or reset
</form>
<p class="frmd"><a href="http://flipkart.com/">FLIPKART</a></p>
<!-- Stop Formoid form-->
</body>
</html>
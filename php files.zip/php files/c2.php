<html>
  <head>
  <title>company's info</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>
 
    
    <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
          
        <br><br>
    
  <body>
  <div id="last" class="form">
       <?php 

         $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="project";
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
            echo 'okay.....';

              }else
          die("Could not connect to database: ");
                                
                                  
                                   $result = mysql_query("SELECT * from `company` where name='hcl'");
                                   $row = mysql_fetch_object($result);
                                   
                                  
                                   echo "<font size=6 face='Arial'>";
                                   echo " COMPANY NAME :";
                                   echo "<font size=5 face='Arial'>";
                                   echo $row->name;
                                   echo  nl2br ("\n");
                                   echo $row->location;
                                   echo  nl2br ("\n");
                                   mysql_free_result($result);
              
          ?>
</div>
</body>
</html>

<html>
<head>
<title>My first template</title>
<link rel="stylesheet" href="templ.css">
</head>
<body background="n2.jpg">
<form method="post" action=hcl.php> 
	<div class="main_body">
        <div class="header">
         <div id="logo"><img src="logo.png" width="300" height="170">
         </div>
            <div id="navigation"><img src="texture.jpg" width="840" height="130" align="right"><font color="white"><h1 id="job">JOBSHALA.com</h1></font></right>
             <h4 id="subjob">Aspiring Jobs</h4>
            </div>
		</div>
       <div class="header1"><body background="white">
            <div id="navigation1">
                <div id="bar"></div>
                <div id="bar"></div><font color="white">
                <div id="bar"><right><img src="signup.jpg" width="55%" height="40px"><left><b><u><a href="http://localhost/proj/signupforjob.php">SIGNUP</a></u></b></left></div>
                <div id="bar"><img src="login.jpg" width="80%" height="40px"><b><u><a href="http://localhost/proj/loginforjob.php">LOGIN</a></u></b></div><right>
                <div id="bar"><right><img src="help.jpg" width="65%" height="40px"><center><a href="helpp.html">HELP</a></center></div><right>
                <div id="bar"><right><img src="gmail.jpg" width="65%" height="40px"><center><a href="http://www.gmail.com//">GMAIL</a></center> </div><right>
                <div id="bar"><img src="dd.png" width="65%" height="40px"><a href="https://www.facebook.com/">FACEBOOK</a></div><right>
                <div id="bar"></div><center>
            </div>
            <div id="navigation2"></div>
        </div>
		<div id="main_content">
        
          <font background="pink" >
		  <h1><center><font color="black"><u><i>JOB BY COMPANY</i></u></font></center></h1>	
			
        <div id="pic1"><right><img src="o.png" width="100%" height="100px" ><center><input type="submit" name="company" value="hcl"></center></img></right></div>
        <div id="pic7"><center><img src="oracle.png" width="100%" height="100px"><center><input type="submit" name="company" value="oracle"></center></img></center></div>
        <div id="pic"><left><img src="cc.png" width="100%" height="100px"><center><input type="submit" name="company" value="reliance"></center></img></left></div>

        <div id="pic4"><right><img src="wipro.jpg" width="100%" height="100px" ><center><input type="submit" name="company" value="wipro"></center></img></right></div>
        <div id="pic5"><center><img src="download.png" width="100%" height="100px"><center><input type="submit" name="company" value="amazon"></center></img></center></div>
        <div id="pic6"><left><img src="ff.png" width="100%" height="100px"><center><input type="submit" name="company" value="cognizant"></center></img></left></div>
        <div id="pic4"><right><img src="paytm.png" width="100%" height="100px" ><center><input type="submit" name="company" value="paytm"></center></img></right></div>
        <div id="pic5"><center><img src="flipkart.jpg" width="100%" height="100px"><center><input type="submit" name="company" value="flipkart"></center></img></center></div>
        <div id="pic6"><left><img src="aa.png" width="100%" height="100px"><center><input type="submit" name="company" value="google"></center></img></left></div>
        <div id="pic4"><right><img src="de.png" width="100%" height="100px" ><center><input type="submit" name="company" value="deloitte"></center></img></right></div>
        <div id="pic5"><center><img src="doc.png" width="100%" height="100px"><center><input type="submit" name="company" value="docomo"></center></img></center></div>
    
        <div id="pic4"><right><img src="no.png" width="100%" height="100px" ><center><input type="submit" name="company" value="novaritis"></center></img></right></div>


	    </div>
	</div>	
	
	
	
	
	
    <div class="footer">
     <font color="white">
			<div id="logo1">
				<div id="1"><br><center><img src="download.jpg" width="170"><center><p><font color="red"><b>"JOBSHALA is one of the best rating site.It's among the 5 best websites where you can find millions of opportunities to find the job tat suits your profile."</b></font><h4>OTHER COMPANIES INCLUDES:<hr id="line1"/></h4></p><a href="http://www1.ap.dell.com/"><img src="dell.png" width="80"></a><br><br><br><br><a href="https://www.infosys.com/"><img src="inf.png" width="80"></a><br><br><br><br><a href="http://bsnl.com/"><img src="hh.png" width="80"></a><br><br><br><br><img src="o.png" width="100"></div>
			</div>
			<div id="nav"><h4><font color="yellow"><center>TOP EMPLOYERS<p><hr id="line1"/><a href="https://www.amazon.in//"> AMAZON.COM</a></p><br>
			<p> <a href="https://www.flipkart.com/">FLIPKART.COM</a></p><br>
            <p><a href="https://www.naukri.com/">NAUKRI.COM</a></p><br>
            <p><a href="http://www.monsterindia.com/">MONSTER.COM</a></p><br>
            <p><a href="http://www.shiksha.com/">SHIKSHA.COM</a></p><br>
			<p><a href="https://www.facebook.com/">FACEBOOK.COM</a></p><br>
			<p><a href="https://www.google.co.in/">GOOGLE.COM</a></p></center><br></font>
			</div>
			<div id="lo"><h4><center>RECOMMENDED SITES<p><hr id="line1"/></center></h4><center><br><img src="intern.png" width="170">
			<br><br><br> <h4><center><font color="green"><u><a href="http://internshala.com/internships">INTERNSHALA.COM</u><p><hr id="line1"/></a></font><br><br>
			
		    </div>
		
			</font>
			</div>
	</div>
 </form>
</body>
</html>	     
	 
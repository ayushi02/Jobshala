<? php
$hostname = "localhost";
$username = "root";
$password = "";
$mydb="project";

$dbhandle = (mysql_connect($hostname, $username, $password)) && (mysql_select_db($mydb));
if($dbhandle){
	echo 'ok u got it';
}else
	die("Could not connect to database: "); 
?>
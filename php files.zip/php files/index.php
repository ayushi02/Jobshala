<html>
<?php
$hostname = "localhost";
$username = "root";
$password = "";
$mydb="test";

//$dbhandle = (mysql_connect($hostname, $username, $password)) && (mysql_select_db($mydb));
if(mysql_connect($hostname, $username, $password) && mysql_select_db($mydb)){
	echo 'ok u got it';
}else
	die("Could not connect to database: "); 


?>
</html>
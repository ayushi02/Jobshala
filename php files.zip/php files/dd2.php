<html>
  <head>
  <title>SUCCESSFULLY  LOGGED IN</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
        <style>
        .button2 {background-color: #f44336;
        border: none;
        color: white;
        padding: 15px 30px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        border-style:solid;
        border-color: white;
        border-radius: 8px;
        cursor: pointer;}
div.img {
    margin: 10px;
    
    float: right;
    width: 50px;
}

div.img:hover {
    border: 4px solid #777;
}

div.img img {
    width: 100%;
    height: auto;
}
div.desc {
    padding: 3px;
    text-align: center;
}
div.box {
    background-color:rgb(255,125,190);
    width: 300px;
    border: 5px solid rgb(11,27,136); ;
    padding: 25px;
    margin: 25px;
}
</style>
    </head>
 
    
    <body bgcolor="#E6E6FA" background="cloud-131.jpg">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
        
       
        <br><br>
    
  <body>
  
	<?php 

	     $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="project";
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
	       }else
	       die("Could not connect to database: ");


		 $cat=$_POST['category'];
		 $user= $_POST['username'];
		 $pass= $_POST['password']; 
		 $date=$_POST['tdate'];
		                             if($cat=='Employee')
                                { $query=mysql_query("UPDATE `job_seeker` SET `login_date`='$date' WHERE username='$user' && password='$pass'");
                                  $query1=mysql_query("UPDATE `job_seeker` SET `date_diff`= DATEDIFF(CURDATE(),login_date)
                                    WHERE username='$user' && password='$pass'");
                                  
                                    
                                  
                                  $result = mysql_query("SELECT * from `job_seeker` where username='$user' && password='$pass'");
                                  $row = mysql_fetch_object($result);
                                  if ($row->id>=0) {
                                  echo "<font size=6 face='Arial'>";
                                  echo " WELCOME  ";
                                  echo "<font size=5 face='Arial'>";
                                  echo $row->f_name;
                                  echo "  ";
                                  echo $row->l_name;
                                  echo " ,\n";
                                  
                                    }
                                  
                                 else {
                                  echo "                  INVALID USERNAME OR PASSWORD...\n                 PLEASE LOGIN AGAIN";
                                  }
                                }
                                if($cat=='Student')
                                {$query=mysql_query("UPDATE `student` SET `login_date`='$date' WHERE username='$user' && password='$pass'");
                                  $result = mysql_query("SELECT * from `student` where username='$user' && password='$pass'");
                                $row = mysql_fetch_object($result);
                               if ($row->id>=0) {
                                  echo "<font size=6 face='Arial'>";
                                  echo " WELCOME  ";
                                  echo "<font size=5 face='Arial'>";
                                  echo $row->f_name;
                                  echo "  ";
                                  echo $row->l_name;
                                  echo " ,\n";
                                  
                                    }
                                  
                                 else {
                                  echo "                  INVALID USERNAME OR PASSWORD...\n                 PLEASE LOGIN AGAIN";
                                  }
                                }
                                if($cat=='Admin')
                                {$query=mysql_query("UPDATE `admin` SET `login_date`='$date' WHERE username='$user' && password='$pass'");
                                  $result = mysql_query("SELECT * from `admin` where username='$user' && password='$pass'");
                                $row = mysql_fetch_object($result);
                                  echo '<center><button class="button2"><b><a href="http://localhost/proj/admin.php">VIEW DATABASE</center></b></button2>';
                                  if ($row->id>=0) {
                                  echo "<font size=6 face='Arial'>";
                                  echo " WELCOME  ";
                                  echo "<font size=5 face='Arial'>";
                                  echo $row->f_name;
                                  echo "  ";
                                  echo $row->l_name;
                                  echo " ,\n";
                                  
                                    }
                                  
                                 else {
                                  echo "                  INVALID USERNAME OR PASSWORD...\n                 PLEASE LOGIN AGAIN";
                                  }
                                }
                             
?>
<div class="img">
    <img src="face3.jpg" alt="user" width="200" height="200">
  
  <div class="desc"> 
   <?php
   echo "<font size=2 face='Arial'>";
   echo $row->username;
   ?>
 </div>
</div>
 <nav>
         <ul>
          <li>
            <a class="button2" href="edit1.php">Edit</a>
          </li>
          <li>
            <a class="button2" href="http://localhost/proj/rec.php">Recommendation</a>
          </li>
          <li>
            <a class="button2" href="helpp.html">Help</a>
          </li>
          <li>
            <a class="button2" href="logout.html">Sign out</a>
          </li>
        </ul>
       </nav>
<div> 
<h2><center>VIEW YOUR PROFILE</h2></center>
<br><br><br>

</div>
<center>
<div class="box">
                           <?php 
                                  echo "<font size=4 face='Arial'>";
                                  echo " FULL NAME :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->f_name;
                                  echo "  ";
                                  echo $row->l_name;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo " DATE OF BIRTH :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->DOB;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  echo " EMAIL :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->email;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  if($cat=='Employee'|| $cat='Admin')
                                  {echo "<font size=4 face='Arial'>";
                                  echo " EXPERIENCE :";
                                  echo "<font size=3 face='Arial'>";
                                 
                                  echo $row->experience;
                                  echo " years.";
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                 }
                                  echo "<font size=4 face='Arial'>";
                                  echo " MOBILE NO :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->mobile_no;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                
                                  echo "<font size=4 face='Arial'>";
                                  echo " LOCATION :";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->location;
                                  echo  nl2br ("\n");
                                  echo  nl2br ("\n");
                                  echo "<font size=4 face='Arial'>";
                                  if($cat=='Employee'|| $cat='Admin')
                                  {echo " QUALIFICATON:";
                                  echo "<font size=3 face='Arial'>";
                                  echo $row->qualification;
                                }
                            ?> 
</div>
</center>
</body>
</html>
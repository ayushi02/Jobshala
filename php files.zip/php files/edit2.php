<html>
  <head>
  <title>SUCCESSFULLY EDITED</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>
 
    
    <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
          
        <br><br>
<?php 

	     $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="project";
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
	       }else
	       die("Could not connect to database: ");


		 $first= $_POST['fname'];
		 $last= $_POST['lname'];
		 $user= $_POST['username'];
		 $mail= $_POST['email'];
		 $pass= $_POST['password']; 
		 $a= $_POST['dob'];
		 $loc=$_POST['location'];
		 $exp= $_POST['experience'];
		 $qua= $_POST['qualification'];
		 $no= $_POST['mobileno'];
     $g=$_POST['gender'];
     $feed= $_POST['feedback'];
		       
	           session_start();
             echo $_SESSION['table'];
             if($_SESSION['table']=='Student')
             {$query = mysql_query("UPDATE `project`.`student` SET `l_name`='$last',`username` = '$user', `password` = '$pass',
                                   `mobile_no`='$no',`location` = '$loc',`DOB`='$a',`gender`='$g',`feedback`='$feed'
                                    WHERE `student`.`f_name` = '$first'");}

           elseif($_SESSION['table']=='Employee')
             { echo 'entered';
              $query = mysql_query("UPDATE `project`.`job_seeker` SET `l_name`='$last',`username` = '$user', `password` = '$pass',`experience` = '$exp',
                                   `mobile_no`='$no',`location` = '$loc',`DOB`='$a',`qualification`='$qua',`gender`='$g',`feedback`='$feed'
                                    WHERE `job_seeker`.`f_name` = '$first'");}

            elseif($_SESSION['table']=='Admin')
             {$query = mysql_query("UPDATE `project`.`admin` SET `l_name`='$last',`username` = '$user', `password` = '$pass',`experience` = '$exp',
                                   `mobile_no`='$no',`location` = '$loc',`dob`='$a',`qualification`='$qua',`gender`='$g',`feedback`='$feed'
                                    WHERE `admin`.`f_name` = '$first'");}
if($query){
 echo "<font size=4 face='Arial'>";
 echo "Hey  ";
 echo "<font size=3 face='Arial'>";
 echo $first;
 echo  nl2br ("\n");
 echo  nl2br ("\n");
 echo  nl2br ("\n"); 
 echo "<font size=4 face='Arial'>";
 
 echo "YOU HAVE SUCCESSFULLY EDITED YOUR PROFILE";
 echo  nl2br ("\n");
 echo "ENJOY SURFING THE SITE";

 if(isset($_POST['submit'])&&($_SESSION['table']=='Employee'||$_SESSION['table']=='Admin'))
   {
     $image_name=$_FILES['image']['name'];
     $image_type=$_FILES['image']['type'];
     $image_size=$_FILES['image']['size'];
     $image_tmp_name=$_FILES['image']['tmp_name'];

     if($image_name=='')
     {
      echo "<script>alert('Please Select an Image')</script>";
        exit();
     }
      else {
          move_uploaded_file($image_tmp_name,"photos/$image_name");
          echo  nl2br ("\n");
          echo  nl2br ("\n");
          echo "Image Uploaded Successfully";
         }  
     }  
     if($_SESSION['table']=='Employee')   
     {$file_name=$_FILES['resume']['name'];
     $file_type=$_FILES['resume']['type'];
     $file_size=$_FILES['resume']['size'];
     $file_tmp_name=$_FILES['resume']['tmp_name'];

     if($image_name=='')
     {
      echo "<script>alert('Please Select your Resume')</script>";
        exit();
     }
      else {
          move_uploaded_file($image_tmp_name,"files/$file_name");
          echo  nl2br ("\n");
          echo  nl2br ("\n");
          echo "Resume Uploaded Successfully";
         }   
   }
 }
else
{
echo "Error....!!";
echo  nl2br ("\n");
echo "TRY AGAIN..";
}

mysql_close($connection);
?>

</body>
</html>
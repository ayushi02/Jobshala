<html>
  <head>
  <title>company's info</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>
 
    
    <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
        
        <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
          
        <br><br>
    
  <body>
  <div id="last" class="form">
       <?php 

         $hostname = "localhost";
         $username = "root";
         $passw = "";
         $mydb="project";
         $connection=mysql_connect($hostname, $username, $passw);
           if(mysql_connect($hostname, $username, $passw) && mysql_select_db($mydb)){
              }else
          die("Could not connect to database: ");
         
                                
                         $res=$_POST['CLICK HERE'];      
                          echo $res;
                          echo  nl2br ("\n");
                          echo  nl2br ("\n");       
                                  switch ($res) {
                                   case 'HCL':
                                   $result = mysql_query("SELECT * from `company` where name='hcl'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'ORACLE':
                                   $result = mysql_query("SELECT * from `company` where name='oracle'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'RELAINCE':
                                   $result = mysql_query("SELECT * from `company` where name='reliance'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'WIPRO':
                                   $result = mysql_query("SELECT * from `company` where name='wipro'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'AMAZON':
                                   $result = mysql_query("SELECT * from `company` where name='amazon'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'COGNIZANT':
                                   $result = mysql_query("SELECT * from `company` where name='cognizant'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'PATYM':
                                   $result = mysql_query("SELECT * from `company` where name='patym'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'FLIPKART':
                                   $result = mysql_query("SELECT * from `company` where name='flipkart'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'GOOGLE':
                                   $result = mysql_query("SELECT * from `company` where name='google'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'DEOLITTE':
                                   $result = mysql_query("SELECT * from `company` where name='deolitte'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   case 'NOVARTIS':
                                   $result = mysql_query("SELECT * from `company` where name='novartis'");
                                   $row = mysql_fetch_object($result);
                                   break;
                                   default:
                                   echo "NO COMPANY FOUND";
                                   break;
                                   }

                                   echo "<font size=6 face='Arial'>";
                                   echo " COMPANY NAME :";
                                   echo "<font size=5 face='Arial'>";
                                   echo $row->name;
                                   echo  nl2br ("\n");
                                   echo $row->location;
                                   echo  nl2br ("\n");
                                   mysql_free_result($result);
              
           
?>
</div>
</body>
</html>
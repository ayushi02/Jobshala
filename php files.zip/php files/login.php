<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
    Created on : 24 Aug, 2016, 10:13:24 PM
    Author     : Divij Bhatia
-->
<?php
    include 'index.php';
    if(isset($_POST['email'])&&isset($_POST['password']))
    {
        if((!empty($_POST['email']) && (!empty($_POST['password']))))
        {
            $email=$_POST['email'];
            $pass=$_POST['password'];
            $query='INSERT INTO `form` VALUES ("","'.$email.'","'.$pass.'")';
            $query_run=mysql_query($query);
        }else{
            echo 'not set.';
        }
    }

?>
<html>
    <head>
        <meta charset="UTF-8" >
        <link rel="stylesheet" href="login.css">
        <script src="login.js"></script>
        <title>LogIn</title>
    </head>
    <body>
        <div id="fullpage">
            <div id="header" >
                <center><span>FLIPKART</span></center>
            </div>
            <div class="form" id="login-form">
                <form method="POST">
                    <input type="email" name="email" placeholder="email">
                    <input type="password" name="password" placeholder="password">
                    <input class="submit" type="submit" value="SUBMIT">
                    <input class="f_name" name="f_name" value="f_name">
                </form>
                <span ><br>
                    Don't have an account? <span class="signup" onclick="showSignupForm();">Sign Up</span> 
                </span>
            </div><br>
            <div class="form" id="signup-form">
                <form method="POST">
                    <input type="text" name="name" placeholder="name">
                    <input type="text" name="address" placeholder="address">
                    <input type="email" name="email"placeholder="email">
                    <input type="password" name="password" placeholder="password">
                    <input type="submit" class="submit" value="SUBMIT">
                </form>
                <span >
                    Already have an account? <span class="signup" onclick="showLoginForm();" >Log In</span> 
                </span>
            </div>
        
        </div>
    </body>
</html>

<html>
    <head>
     <head>
     <style>
      .error {color: #FF0000;}
      
     </style>
        <title>JOBSHALA LOGIN IN</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>   
       <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
     <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
        
        <br><br>
        <script type="text/javascript">
       tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
       tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

      function GetClock(){
var d=new Date();
var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear();
if(nyear<1000) nyear+=1900;
var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

if(nhour==0){ap=" AM";nhour=12;}
else if(nhour<12){ap=" AM";}
else if(nhour==12){ap=" PM";}
else if(nhour>12){ap=" PM";nhour-=12;}

if(nmin<=9) nmin="0"+nmin;
if(nsec<=9) nsec="0"+nsec;

document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+ap+"";
}

window.onload=function(){
GetClock();
setInterval(GetClock,1000);
}
</script>

<div id="clockbox" align="right"></div>
         
        
        
<div id="last" class="form">
<form method="post" action=dd3.php method=post>
<ul class="errorMessages"></ul>
    <center>  <h2>LOGIN IN here</h2></center><br>
   <center> 
   <center><B>SELECT YOUR CATEGORY :<B>
   <select name="category">
   <option value="null">--Choose an option--</option>
   <option value="Student">Student</option>
  <option value="Employee">Employee</option>
  <option value="Admin">Admin</option>
   </select>
</center>
<br><br><br>
   <div>
        <label for="username"><b>Userame:</b></label>
        <input id="username" type="text" name="username" required>
    </div>
<br>
    <div>
        <label for="password"><b>Password:</b></label>
        <input id="password" type="text" name="password" required>
    </div>
     <b>Today's Date:</b> <input type="date" name="tdate">
     <br><br>
    <br>
    <div class="buttons">
        <button>Submit</button>
    </div>
    </center>
    </form>


    <script>
    var createAllErrors = function() {
        var form = $( this ),
            errorList = $( "ul.errorMessages", form );

        var showAllErrorMessages = function() {
            errorList.empty();

            // Find all invalid fields within the form.
            var invalidFields = form.find( ":invalid" ).each( function( index, node ) {

                // Find the field's corresponding label
                var label = $( "label[for=" + node.id + "] "),
                    // Opera incorrectly does not fill the validationMessage property.
                    message = node.validationMessage || 'Invalid value.';

                errorList
                    .show()
                    .append( "<li><span>" + label.html() + "</span> " + message + "</li>" );
            });
        };

        // Support Safari
        form.on( "submit", function( event ) {
            if ( this.checkValidity && !this.checkValidity() ) {
                $( this ).find( ":invalid" ).first().focus();
                event.preventDefault();
            }
        });

        $( "input[type=submit], button:not([type=button])", form )
            .on( "click", showAllErrorMessages);

        $( "input", form ).on( "keypress", function( event ) {
            var type = $( this ).attr( "type" );
            if ( /date|email|month|number|search|tel|text|time|url|week/.test ( type )
              && event.keyCode == 13 ) {
                showAllErrorMessages();
            }
        });
    };
    
    $( "form" ).each( createAllErrors );
</script>
<?php
$hostname = "localhost";
$username = "root";
$password = "";
$mydb="test";


if(mysql_connect($hostname, $username, $password) && mysql_select_db($mydb)){
  
}else
  die("Could not connect to database: "); 


?>
</body>
</html>
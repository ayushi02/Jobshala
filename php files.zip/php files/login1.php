<html>
    <head>
     <head>
     <style>
      .error {color: #FF0000;}
     </style>
        <title>JOBSHALA LOGIN IN</title>
        <meta http-equiv="author">
        <meta description="description" content="Jobshala.com aspiring Jobs"> 
    </head>   
       <body bgcolor="#E6E6FA" background ="cloud-131.jpg">
     <link rel="stylesheet" type="text/css" href="edit.css">
        <img src="banner.png" id="banner">
       
        <div class="top">
            <a href="https://jobshala.com"><img src="logo.png" id="logo"></a>
            <a href="https://jobshala.com"><h1 id="job">JOBSHALA</h1></a>
            <h4 id="subjob">Aspiring Jobs</h4>
        </div>
        
        <br><br>
        
      <!-- ADD LINK HERE IN HREF SEEEEEEEEEEEEEEEEEEE BELOW -->  
        
          <center>  <h2>LOGIN IN here</h2></center><br>
       
      <!-- ADD LINK HERE IN HREF SEEEEEEEEEEEEEEEEEEE ABOVE -->
        
        
<div id="last" >
<?php
// define variables and set to empty values
$usernameErr = $passwordErr="";
$username = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
  if (empty($_POST["username"])) {
    $usernameErr = "User Name is required";
  } else {
    $username = test_input($_POST["username"]);
  }
  
  
  if (empty($_POST["password"])) {
    $passwordErr = "password id required";
  } else {
    $password = test_input($_POST["password"]);
  }

  
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>

<center>
<p><span class="error">* required field.</span></p>
<form method="post" action="<?php echo $data ?>">

 <b> User Name:</b> <input type="text" name="username">
  <span class="error">* <?php echo $usernameErr;?></span>
  <br><br>
  
  <b>Password:</b> <input type="text" name="password">
  <span class="error">* <?php echo $passwordErr;?></span>
  <br><br>
  
  <input type="submit" name="submit" value="Submit">  
</form>
 
</div>
</body>
</html>